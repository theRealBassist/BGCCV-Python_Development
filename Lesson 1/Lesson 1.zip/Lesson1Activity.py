### Lesson1Activity.py ###

### Dog Years Activity ###
# Create a program that calculates a dog's age in "dog years" based on the 
# popular myth that one human year equals 7 dog years.
# Have the user input a dog's name and age. Then calculate and print the 
# dog's age in human years and in dog years.

### Example Output ###

# Enter your dog's name: Rex
# Enter your dog's age: 4

# Rex is 4 in human years
# Rex is 28 in dog years

### Your code goes below here ###