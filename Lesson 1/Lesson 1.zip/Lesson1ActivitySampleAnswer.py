### Lesson1ActivitySampleAnswer.py ###

name = input("Enter your dog's name: ")
age = int(input("Enter your dog's age: "))

humanYears = age
dogYears = age * 7

print() # Prints an empty line
print(name + " is " + str(humanYears) + " in human years")
print(name + " is " + str(dogYears) + " in dog years")